# 个人作品集网站

React + Vite + Tailwind CSS v4 + Framer Motion。暗色系，PC 端优先，版心 1700px。

## 怎么打开

**双击 `启动预览.bat`** —— 会自动启动本地预览并打开浏览器，地址是 http://127.0.0.1:5183/
关掉那个黑色窗口就等于停止预览。

> 注意：这是**本地预览**，只有这台电脑能看。要给别人一个真实网址，需要部署到 Vercel / Netlify（见文末）。

## 改内容

所有文案、项目、联系方式都在 **`src/data/profile.js`** 一个文件里，改完存盘，页面会自动刷新。

需要替换的占位符：

- `name` / `monogram` — 姓名（`monogram` 是导航左上角的小徽标，填姓氏即可）
- `contacts` — 邮箱 / 手机 / 微信号
- `about.portrait` — 换成你自己的照片

## 目录

```
src/
  data/profile.js        所有内容集中在这里
  sections/              五个区块：Hero / About / Work / Edge / Contact
  components/            导航、首屏 canvas 背景、滚动入场动画、区块标题
  index.css              设计变量（配色、字体）与 1700px 版心
public/
  fonts/                 本地字体 Outfit + Geist Mono（无 CDN 依赖）
  assets/images/         项目配图（当前是抽象 SVG，换成真实截图即可）
  assets/videos/         首屏视频背景槽位，见该目录 README.md
```

## 换配色

改 `src/index.css` 里 `@theme` 中的变量即可，重点是两个：

- `--color-ink` 页面底色
- `--color-accent` 强调色（现在是暖铜色 `#d97757`）

## 首屏视频背景

默认关闭，用 canvas 动画承载。放一段 `hero-loop.mp4` 到 `public/assets/videos/`，
再把 `profile.js` 里 `heroVideo: ''` 改成 `'/assets/videos/hero-loop.mp4'` 即可生效。

## 部署到线上（拿到真实网址）

```bat
npm run build
```

产物在 `dist/` 目录。把整个项目推到 GitHub，然后在 Vercel / Netlify 里导入仓库即可，
无需任何额外配置（纯静态站点，构建命令 `npm run build`，输出目录 `dist`）。