# 首屏视频背景槽位

首屏 Hero 已经预留了视频背景层，但**默认关闭**（避免请求不存在的文件产生 404）。

## 启用方式

1. 把一段循环视频放到本目录，命名为 `hero-loop.mp4`
   （建议：1920x1080 或 1600x900、6—10 秒、静音循环、H.264、体积 < 4MB）
2. 打开 `src/data/profile.js`，把 `heroVideo: ''` 改为：

   ```js
   heroVideo: '/assets/videos/hero-loop.mp4',
   ```

刷新页面即可。视频层以 `mix-blend-screen` 叠在 Canvas 动态背景之上，透明度 40%，所以最好选**深底浅形**的抽象/粒子类素材。

## 未启用时

首屏由 `src/components/HeroBackdrop.jsx` 里的 Canvas 动态背景承载：漂移点阵 + 跟随鼠标的高光点 + 缓慢移动的暖色光晕。它是纯代码绘制，不依赖任何外部素材，也不会产生额外网络请求。

## 海报帧

`public/assets/images/hero-poster.svg` 是视频加载前显示的海报帧，可替换成视频的第一帧截图。