// AI生成
import Nav from './components/Nav.jsx'
import Hero from './sections/Hero.jsx'
import About from './sections/About.jsx'
import Work from './sections/Work.jsx'
import Edge from './sections/Edge.jsx'
import Contact from './sections/Contact.jsx'

export default function App() {
  return (
    <>
      <a
        href="#about"
        className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[60] focus:bg-accent focus:px-4 focus:py-2 focus:text-sm focus:text-ink"
      >
        跳到主要内容
      </a>
      <Nav />
      <main>
        <Hero />
        <About />
        <Work />
        <Edge />
        <Contact />
      </main>
    </>
  )
}