// AI生成
import { memo, useEffect, useRef } from 'react'

const ACCENT = '217, 119, 87'
const DOT = '236, 235, 232'

/**
 * Perpetual canvas motion is isolated here in a memoised leaf component so it
 * never re-renders with the page. Animates a drifting dot field with a slow
 * accent glow; dots near the cursor light up and get pulled slightly in.
 */
function HeroBackdropInner() {
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || typeof canvas.getContext !== 'function') return

    const ctx = canvas.getContext('2d')
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const coarse = window.matchMedia('(pointer: coarse)').matches

    let width = 0
    let height = 0
    let dpr = 1
    let dots = []
    let raf = 0
    let t = 0
    const pointer = { x: -9999, y: -9999 }

    const build = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2)
      width = canvas.clientWidth || window.innerWidth
      height = canvas.clientHeight || window.innerHeight
      canvas.width = Math.max(1, Math.floor(width * dpr))
      canvas.height = Math.max(1, Math.floor(height * dpr))
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)

      const gap = width < 768 ? 58 : width < 1280 ? 66 : 78
      const cap = width < 768 ? 100 : width < 1280 ? 300 : 800
      dots = []
      for (let x = gap / 2; x < width && dots.length < cap; x += gap) {
        for (let y = gap / 2; y < height && dots.length < cap; y += gap) {
          const seed = Math.random()
          dots.push({
            x,
            y,
            phase: seed * Math.PI * 2,
            amp: 4 + seed * 10,
            speed: 0.00022 + seed * 0.00034,
          })
        }
      }
    }

    const paint = (moving) => {
      ctx.clearRect(0, 0, width, height)

      const gx = width * (0.64 + 0.11 * Math.sin(t * 0.0032))
      const gy = height * (0.4 + 0.09 * Math.cos(t * 0.0026))
      const glow = ctx.createRadialGradient(gx, gy, 0, gx, gy, Math.max(width, height) * 0.44)
      glow.addColorStop(0, `rgba(${ACCENT}, 0.17)`)
      glow.addColorStop(0.42, `rgba(${ACCENT}, 0.05)`)
      glow.addColorStop(1, 'rgba(0,0,0,0)')
      ctx.fillStyle = glow
      ctx.fillRect(0, 0, width, height)

      for (let i = 0; i < dots.length; i += 1) {
        const d = dots[i]
        const dx = d.x - pointer.x
        const dy = d.y - pointer.y
        const dist = Math.sqrt(dx * dx + dy * dy)
        const pull = dist < 220 && !coarse ? 1 - dist / 220 : 0
        const ox = moving ? Math.sin(t * d.speed + d.phase) * d.amp : 0
        const oy = moving ? Math.cos(t * d.speed * 0.8 + d.phase) * d.amp * 0.6 : 0
        const px = d.x + ox - dx * pull * 0.1
        const py = d.y + oy - dy * pull * 0.1
        const alpha = 0.1 + pull * 0.7

        ctx.beginPath()
        ctx.arc(px, py, pull > 0.2 ? 1.6 : 1, 0, Math.PI * 2)
        ctx.fillStyle =
          pull > 0.25 ? `rgba(${ACCENT}, ${alpha.toFixed(3)})` : `rgba(${DOT}, ${alpha.toFixed(3)})`
        ctx.fill()
      }
    }

    const loop = () => {
      t += 1
      paint(true)
      raf = window.requestAnimationFrame(loop)
    }

    const onPointer = (event) => {
      const rect = canvas.getBoundingClientRect()
      pointer.x = event.clientX - rect.left
      pointer.y = event.clientY - rect.top
    }
    const onLeave = () => {
      pointer.x = -9999
      pointer.y = -9999
    }

    const onResize = () => {
      build()
      if (!moving) paint(false)
    }

    let moving = !reduce
    build()

    if (moving) {
      raf = window.requestAnimationFrame(loop)
      if (!coarse) window.addEventListener('pointermove', onPointer, { passive: true })
      window.addEventListener('pointerleave', onLeave)
    } else {
      paint(false)
    }
    window.addEventListener('resize', onResize)

    return () => {
      window.cancelAnimationFrame(raf)
      window.removeEventListener('pointermove', onPointer)
      window.removeEventListener('pointerleave', onLeave)
      window.removeEventListener('resize', onResize)
    }
  }, [])

  return <canvas ref={canvasRef} aria-hidden="true" className="h-full w-full" />
}

const HeroBackdrop = memo(HeroBackdropInner)
export default HeroBackdrop