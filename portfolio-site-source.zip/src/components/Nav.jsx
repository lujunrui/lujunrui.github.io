// AI生成
import { useEffect, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import profile from '../data/profile.js'

const PANEL_EASE = [0.16, 1, 0.3, 1]

export default function Nav() {
  const [lifted, setLifted] = useState(false)
  const [open, setOpen] = useState(false)
  const reduce = useReducedMotion()

  useEffect(() => {
    const onScroll = () => setLifted(window.scrollY > 40)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // 菜单展开时锁定页面滚动
  useEffect(() => {
    if (!open) return undefined
    const previous = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = previous
    }
  }, [open])

  useEffect(() => {
    if (!open) return undefined
    const onKey = (event) => {
      if (event.key === 'Escape') setOpen(false)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open])

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-500 ${
        lifted || open
          ? 'border-b border-line bg-ink/92 backdrop-blur-xl'
          : 'border-b border-transparent'
      }`}
    >
      <div className="shell flex h-[74px] items-center justify-between gap-4">
        <a
          href="#hero"
          onClick={() => setOpen(false)}
          className="group flex items-baseline gap-3"
        >
          <span className="flex h-8 min-w-8 items-center justify-center border border-line px-2 font-mono text-[12px] text-accent transition-colors duration-300 group-hover:border-accent">
            {profile.monogram}
          </span>
          <span className="hidden font-mono text-[11px] tracking-[0.3em] text-dim uppercase sm:inline">
            Portfolio
          </span>
        </a>

        <nav className="hidden items-center gap-9 lg:flex" aria-label="主导航">
          {profile.nav.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-[13px] text-dim transition-colors duration-200 hover:text-fog"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2.5">
          <a
            href="#contact"
            className="hidden border border-menu px-5 py-2.5 text-[13px] text-fog transition-colors duration-300 hover:border-accent hover:bg-accent hover:text-ink active:scale-[0.98] sm:inline-block"
          >
            联系我
          </a>

          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            aria-label={open ? '关闭菜单' : '打开菜单'}
            aria-expanded={open}
            aria-controls="mobile-menu"
            className="flex h-9 w-9 items-center justify-center border border-line text-fog transition-colors duration-300 hover:border-accent active:scale-[0.97] lg:hidden"
          >
            <svg
              viewBox="0 0 18 18"
              className="h-[18px] w-[18px]"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.6"
              aria-hidden="true"
            >
              {open ? (
                <>
                  <line x1="4" y1="4" x2="14" y2="14" />
                  <line x1="14" y1="4" x2="4" y2="14" />
                </>
              ) : (
                <>
                  <line x1="2.5" y1="5.5" x2="15.5" y2="5.5" />
                  <line x1="2.5" y1="12.5" x2="15.5" y2="12.5" />
                </>
              )}
            </svg>
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open ? (
          <motion.nav
            id="mobile-menu"
            aria-label="移动端导航"
            className="border-t border-line bg-ink/95 backdrop-blur-xl lg:hidden"
            initial={reduce ? false : { opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={reduce ? undefined : { opacity: 0, y: -10 }}
            transition={{ duration: 0.28, ease: PANEL_EASE }}
          >
            <div className="shell flex flex-col py-3">
              {profile.nav.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="border-b border-line py-4 text-[15px] text-fog"
                >
                  {item.label}
                </a>
              ))}
              <a
                href="#contact"
                onClick={() => setOpen(false)}
                className="mt-5 bg-accent px-6 py-3.5 text-center text-[14px] font-medium text-ink active:scale-[0.98]"
              >
                联系我
              </a>
            </div>
          </motion.nav>
        ) : null}
      </AnimatePresence>
    </header>
  )
}