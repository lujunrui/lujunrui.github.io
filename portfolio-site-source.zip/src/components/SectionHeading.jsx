// AI生成
export default function SectionHeading({ index, title, lead, id }) {
  return (
    <div id={id} className="shell pt-24 md:pt-36">
      <div className="flex items-baseline gap-6 border-t border-line pt-5">
        <span className="font-mono text-[11px] tracking-[0.28em] text-accent">{index}</span>
        <h2 className="text-2xl font-bold tracking-tight md:text-4xl">{title}</h2>
      </div>
      {lead ? (
        <p className="mt-6 max-w-[65ch] text-sm leading-relaxed text-dim md:text-base">{lead}</p>
      ) : null}
    </div>
  )
}