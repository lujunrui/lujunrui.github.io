// AI生成
/**
 * 站内所有文案与链接集中在这一处，改内容不用碰组件。
 * 带【】的是占位符，需要你替换成真实信息。
 */
export const profile = {
  name: '【姓名】',
  monogram: '【姓】',
  title: '懂技术的表达者',
  kicker: '2028 届 · 软件工程 · 面向 B端 / AI 产品与售前方向',
  summary:
    '软件工程在读，习惯把需求理清、把方案讲明、把项目推到底。主攻 B端 / AI 产品经理与售前解决方案方向，城市落点长三角与珠三角。',

  // 视频背景：把 hero-loop.mp4 放进 public/assets/videos/ 后，改成 '/assets/videos/hero-loop.mp4'
  // 留空时由下方 Canvas 动态背景承载，不会有 404 请求。
  heroVideo: '',
  heroPoster: '/assets/images/hero-poster.svg',

  nav: [
    { label: '概览', href: '#hero' },
    { label: '经历', href: '#about' },
    { label: '项目', href: '#work' },
    { label: '优势', href: '#edge' },
    { label: '联系', href: '#contact' },
  ],

  heroStats: [
    { value: '2028', label: '届 · 本科在读' },
    { value: 'CET-4 530', label: '备考六级 · 目标 550+' },
    { value: '2', label: '个独立完成的可展示项目' },
    { value: '1', label: '项国家级竞赛参赛作品' },
  ],

  about: {
    portrait: '/assets/images/portrait.svg',
    portraitNote: '【替换为个人照片：建议 3:4 竖构图、深色背景】',
    paragraphs: [
      '山西籍，洛阳理工学院软件工程专业在读，2028 届本科毕业，计划本科直接就业。',
      '我把自己放在「技术与业务之间」：既能读懂代码、数据和系统，也能把需求写成别人能执行、能验收的文档。在校内的小组作业和竞赛里，我习惯主动担任组织者和汇报人——把复杂方案讲成听众能接住的话，是我最擅长的事。',
      '英语四级 530 分，正在备考六级（目标 550+）。长期目标是把这套能力用在 B端 / AI 产品、售前与解决方案这类「懂技术 + 会表达」的复合岗位上。',
    ],
    facts: [
      { label: '城市意向', value: '上海 · 苏州 · 深圳 · 广州' },
      { label: '出差', value: '适度可接受' },
      { label: '英语', value: 'CET-4 530 · 备考六级 550+' },
      { label: '主攻方向', value: 'B端 / AI 产品 · 售前 · 实施' },
    ],
    metrics: [
      { value: '12 + 3', unit: '章 / 附录', label: '参赛策划书产出规模' },
      { value: '2', unit: '个', label: '独立完成的完整项目' },
      { value: '1', unit: '项', label: '国家级竞赛参赛作品（2027 届）' },
      { value: '530', unit: '分', label: '大学英语四级' },
    ],
  },

  projects: [
    {
      title: '归栖 · 宠物领养「后市场」守护服务',
      category: '竞赛作品 · 中国大学生服务外包创新创业大赛 C 类',
      year: '2026 — 2027',
      status: '进行中',
      wide: true,
      summary:
        '为宠物领养之后的「回访与成长」环节设计一套 To B 服务：AI 领养回访机器人 + 领养成长档案，面向救助站、基金会、宠物医院与宠物品牌。',
      role: '独立完成：选题论证 · 用户与需求调研 · 市场与竞品分析 · 商业模式设计 · 参赛材料撰写',
      deliverables: [
        '参赛策划书 12 章 + 3 附录',
        '按技术 / 市场 / 商业 / OPC 四维评分表反推的结构设计',
        '配套研究报告与结构源文件',
      ],
      image: '/assets/images/work-guixi.svg',
    },
    {
      title: '识别类微信小程序原型',
      category: '独立开发 · 产品原型',
      year: '2024 — 2025',
      status: '已完成',
      summary:
        '一个带扫描与图像识别能力的微信小程序，用来验证「用手机完成信息采集」的产品假设，并把流程压缩到三步以内。',
      role: '独立完成：需求拆解 · 页面原型 · 前端实现 · 自测',
      deliverables: ['可演示的小程序原型', '页面与操作流程图', '功能清单与优先级排序'],
      image: '/assets/images/work-miniapp.svg',
    },
    {
      title: 'B端 SaaS 工具竞品分析',
      category: '产品作品 · 大二上',
      year: '2026',
      status: '进行中',
      summary:
        '选定一款熟悉的 SaaS 工具做拆解：功能矩阵、定价与商业策略、真实用户评价，最后收口到可落地的改进建议。',
      role: '独立完成：调研设计 · 信息搜集 · 分析与报告撰写',
      deliverables: ['竞品分析报告 1 篇', '功能对比矩阵', '改进建议清单'],
      image: '/assets/images/work-saas.svg',
    },
  ],

  strengths: [
    {
      title: '需求拆解与文档产出',
      body: '把模糊的口头需求写成可执行、可验收的条目。产出物覆盖 PRD、竞品分析、参赛策划书三类文档。',
    },
    {
      title: '表达与汇报',
      body: '在小组作业与竞赛中主动担任组织者与汇报人，习惯先给结论、再给依据，把方案讲成对方能接住的话。',
    },
    {
      title: '英语与跨文化沟通',
      body: 'CET-4 530 分，备考六级目标 550+；坚持英文文档阅读与英文自我介绍训练，目标是能直接对接海外团队。',
    },
    {
      title: '数据与工具',
      body: 'Excel 熟练，能写 SQL 查询；用 Figma / Axure 画原型，用 Git 管理版本，日常用 AI 工具提效。',
    },
    {
      title: '技术理解力',
      body: '数据结构、数据库、计算机网络在学；能读懂代码与接口文档，和研发对齐技术口径时不掉线。',
    },
    {
      title: '规划与推进',
      body: '把目标拆成周期与验收标准，并跟踪到闭合——例如把「寒假前拿到远程实习」拆成 11 周逐周行动表。',
    },
  ],

  // 联系方式：不写 href，避免出现假链接；点「复制」即可拿走
  contacts: [
    { label: '邮箱', value: '【邮箱】' },
    { label: '手机', value: '【手机】' },
    { label: '微信', value: '【微信号】' },
    { label: '城市', value: '洛阳 · 意向上海 / 苏州 / 深圳 / 广州' },
  ],

  closing: {
    line: '如果你在找一位懂技术、能表达、会推进的人',
    emphasis: '我们聊聊。',
    note: '远程实习与 2028 届校招机会都欢迎，简历可随时发送。',
  },
}

export default profile