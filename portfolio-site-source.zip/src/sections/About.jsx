// AI生成
import profile from '../data/profile.js'
import Reveal from '../components/Reveal.jsx'
import SectionHeading from '../components/SectionHeading.jsx'

const { about } = profile

export default function About() {
  return (
    <section id="about" className="pb-24 md:pb-36">
      <SectionHeading
        index="01 / Profile"
        title="经历与位置"
        lead="我把技术当作理解系统的工具，把表达当作推动事情的手段——两者叠在一起，就是我在团队里的位置。"
      />

      <div className="shell mt-14 grid grid-cols-12 gap-x-4 gap-y-12 md:gap-x-12 md:gap-y-14">
        <Reveal className="col-span-12 min-w-0 md:col-span-4 lg:col-span-3">
          <div className="w-full max-w-[300px] overflow-hidden border border-line bg-surface p-2 md:max-w-none">
            <img
              src={about.portrait}
              alt="个人照片（待替换为真实照片）"
              className="aspect-[3/4] h-auto w-full max-w-full object-cover"
              loading="lazy"
            />
          </div>
          <p className="mt-4 font-mono text-[10px] leading-relaxed tracking-[0.12em] text-dim">
            {about.portraitNote}
          </p>
        </Reveal>

        <div className="col-span-12 min-w-0 md:col-span-8 lg:col-span-8 lg:col-start-5">
          <Reveal>
            <div className="max-w-[65ch] space-y-6 text-[15px] leading-[1.85] text-fog/88 md:text-base">
              {about.paragraphs.map((text) => (
                <p key={text.slice(0, 12)}>{text}</p>
              ))}
            </div>
          </Reveal>

          <Reveal delay={0.1}>
            <dl className="mt-12 grid grid-cols-1 sm:grid-cols-2">
              {about.facts.map((fact) => (
                <div key={fact.label} className="border-t border-line py-5 pr-6">
                  <dt className="font-mono text-[10px] tracking-[0.24em] text-dim uppercase">
                    {fact.label}
                  </dt>
                  <dd className="mt-2 text-[14px] text-fog">{fact.value}</dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>
      </div>

      <Reveal className="shell mt-16">
        <dl className="grid grid-cols-2 border-t border-line lg:grid-cols-4">
          {about.metrics.map((metric, index) => (
            <div
              key={metric.label}
              className={`min-w-0 py-8 ${index % 2 === 1 ? 'border-l border-line pl-6' : ''} ${
                index >= 2 ? 'border-t border-line lg:border-t-0' : ''
              } ${index > 0 ? 'lg:border-l lg:border-line lg:pl-8' : ''}`}
            >
              <dd className="flex items-baseline gap-2">
                <span className="text-3xl font-bold tracking-tight md:text-4xl">{metric.value}</span>
                <span className="font-mono text-[11px] text-dim">{metric.unit}</span>
              </dd>
              <dt className="mt-3 font-mono text-[10px] tracking-[0.2em] text-dim uppercase">
                {metric.label}
              </dt>
            </div>
          ))}
        </dl>
      </Reveal>
    </section>
  )
}