// AI生成
import { useState } from 'react'
import profile from '../data/profile.js'
import Reveal from '../components/Reveal.jsx'

function ContactRow({ label, value }) {
  const [copied, setCopied] = useState(false)

  const onCopy = async () => {
    try {
      await navigator.clipboard.writeText(value)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1500)
    } catch {
      setCopied(false)
    }
  }

  return (
    <div className="border-t border-line py-6">
      <p className="font-mono text-[10px] tracking-[0.24em] text-dim uppercase">{label}</p>
      <div className="mt-3 flex items-baseline justify-between gap-6">
        <span className="text-[15px] break-all text-fog md:text-lg">{value}</span>
        <button
          type="button"
          onClick={onCopy}
          aria-live="polite"
          className="shrink-0 border border-line px-3.5 py-1.5 font-mono text-[10px] tracking-[0.18em] text-dim uppercase transition-colors duration-300 hover:border-accent hover:text-accent active:scale-[0.97]"
        >
          {copied ? '已复制' : '复制'}
        </button>
      </div>
    </div>
  )
}

export default function Contact() {
  const { closing } = profile

  return (
    <section
      id="contact"
      className="relative flex min-h-[100dvh] flex-col justify-between overflow-hidden pb-10"
    >
      <div className="ruler absolute inset-0 opacity-60" aria-hidden="true" />
      <div className="absolute -right-40 -bottom-40 h-[560px] w-[560px] rounded-full bg-accent/8 blur-3xl" aria-hidden="true" />

      <div className="shell relative z-10 flex grow flex-col justify-center pt-28">
        <Reveal>
          <p className="font-mono text-[11px] tracking-[0.3em] text-accent uppercase">
            04 / Contact
          </p>
        </Reveal>

        <Reveal delay={0.08}>
          <h2 className="mt-8 max-w-[20ch] text-[clamp(2.2rem,5.4vw,4.9rem)] leading-[1.02] font-bold tracking-[-0.04em]">
            {closing.line}，{'\n'}
            <span className="text-accent">{closing.emphasis}</span>
          </h2>
        </Reveal>

        <Reveal delay={0.16}>
          <p className="mt-8 max-w-[52ch] text-[15px] leading-relaxed text-dim">{closing.note}</p>
        </Reveal>

        <Reveal delay={0.24}>
          <div className="mt-16 grid grid-cols-1 gap-x-14 md:grid-cols-2">
            {profile.contacts.map((contact) => (
              <ContactRow key={contact.label} label={contact.label} value={contact.value} />
            ))}
          </div>
        </Reveal>
      </div>

      <footer className="shell relative z-10 flex flex-col gap-4 border-t border-line pt-7 md:flex-row md:items-center md:justify-between">
        <p className="font-mono text-[10px] tracking-[0.2em] text-dim uppercase">
          {profile.name} · Portfolio 2026
        </p>
        <p className="font-mono text-[10px] tracking-[0.2em] text-dim uppercase">
          Built with React · Vite · Tailwind
        </p>
      </footer>
    </section>
  )
}