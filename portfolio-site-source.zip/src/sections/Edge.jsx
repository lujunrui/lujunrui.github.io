// AI生成
import profile from '../data/profile.js'
import Reveal from '../components/Reveal.jsx'
import SectionHeading from '../components/SectionHeading.jsx'

export default function Edge() {
  return (
    <section id="edge" className="pb-24 md:pb-36">
      <SectionHeading
        index="03 / Edge"
        title="个人优势"
        lead="六项能直接落到工作上的能力。每一项都对应一件我已经做过、并且能展开讲的事。"
      />

      <div className="shell mt-14 grid grid-cols-12 gap-px bg-line">
        {profile.strengths.map((item, index) => (
          <Reveal
            key={item.title}
            delay={index * 0.06}
            className="col-span-12 bg-ink md:col-span-6"
          >
            <div className="h-full p-8 md:p-10">
              <span className="font-mono text-[10px] tracking-[0.26em] text-accent">
                {String(index + 1).padStart(2, '0')}
              </span>
              <h3 className="mt-5 text-lg font-bold tracking-tight md:text-xl">{item.title}</h3>
              <p className="mt-4 text-[14px] leading-relaxed text-dim md:text-[15px]">{item.body}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  )
}