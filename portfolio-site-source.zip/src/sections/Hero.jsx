// AI生成
import profile from '../data/profile.js'
import HeroBackdrop from '../components/HeroBackdrop.jsx'
import Reveal from '../components/Reveal.jsx'

export default function Hero() {
  return (
    <section id="hero" className="relative min-h-[100dvh] overflow-hidden">
      {/* Background stack: canvas motion, optional video, hairline grid */}
      <div className="absolute inset-0">
        <HeroBackdrop />
        {profile.heroVideo ? (
          <video
            className="absolute inset-0 h-full w-full object-cover opacity-40 mix-blend-screen"
            src={profile.heroVideo}
            poster={profile.heroPoster}
            autoPlay
            muted
            loop
            playsInline
          />
        ) : null}
        <div className="ruler absolute inset-0 opacity-70" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-ink" />
      </div>

      <div className="shell relative z-10 flex min-h-[100dvh] flex-col justify-between pt-[74px] pb-12 md:pb-16">
        <div className="grid grow grid-cols-12 items-center gap-x-4 gap-y-12 pt-10 md:gap-x-10 md:pt-16">
          <div className="col-span-12 lg:col-span-8">
            <Reveal>
              <p className="font-mono text-[11px] tracking-[0.3em] text-accent uppercase">
                {profile.kicker}
              </p>
            </Reveal>

            <Reveal delay={0.08}>
              <h1 className="mt-7 text-[clamp(2.4rem,7.4vw,7rem)] leading-[0.94] font-bold tracking-[-0.045em]">
                {profile.title}
              </h1>
            </Reveal>

            <Reveal delay={0.16}>
              <p className="mt-8 max-w-[54ch] text-[15px] leading-relaxed text-dim md:text-base">
                {profile.summary}
              </p>
            </Reveal>

            <Reveal delay={0.24}>
              <div className="mt-11 flex flex-wrap items-center gap-4">
                <a
                  href="#contact"
                  className="bg-accent px-7 py-3.5 text-[14px] font-medium text-ink transition-transform duration-200 hover:brightness-110 active:scale-[0.98]"
                >
                  联系我
                </a>
                <a
                  href="#work"
                  className="border border-menu px-7 py-3.5 text-[14px] text-fog transition-colors duration-300 hover:border-fog active:scale-[0.98]"
                >
                  查看项目
                </a>
              </div>
            </Reveal>
          </div>

          <div className="col-span-12 lg:col-span-4 lg:justify-self-end">
            <Reveal delay={0.32} className="w-full max-w-[320px] border-l border-line pl-6">
              <p className="font-mono text-[10px] tracking-[0.28em] text-dim uppercase">Now</p>
              <p className="mt-4 text-[13px] leading-relaxed text-fog">
                在学：数据结构 · 数据库 / SQL · 计算机网络
              </p>
              <p className="mt-3 text-[13px] leading-relaxed text-dim">
                在备：六级 550+ · 服创大赛 C 类参赛作品
              </p>
              <p className="mt-6 font-mono text-[10px] tracking-[0.24em] text-dim uppercase">
                Scroll ↓
              </p>
            </Reveal>
          </div>
        </div>

        <div className="mt-14 border-t border-line">
          <dl className="grid grid-cols-2 lg:grid-cols-4">
            {profile.heroStats.map((stat, index) => (
              <div
                key={stat.label}
                className={`px-1 py-6 lg:px-0 lg:py-7 ${index > 0 ? 'lg:border-l lg:border-line lg:pl-8' : ''}`}
              >
                <dt className="font-mono text-[10px] tracking-[0.24em] text-dim uppercase">
                  {stat.label}
                </dt>
                <dd className="mt-2.5 text-xl font-bold tracking-tight md:text-2xl">{stat.value}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  )
}