// AI生成
import profile from '../data/profile.js'
import Reveal from '../components/Reveal.jsx'
import SectionHeading from '../components/SectionHeading.jsx'

function ProjectCard({ project, wide }) {
  return (
    <Reveal className={wide ? 'col-span-12 min-w-0' : 'col-span-12 min-w-0 lg:col-span-6'}>
      <article className="group flex h-full min-w-0 flex-col border border-line bg-surface transition-colors duration-500 hover:border-menu">
        <div className="relative overflow-hidden">
          <img
            src={project.image}
            alt={`${project.title} 视觉图`}
            className={`w-full object-cover transition-transform duration-[900ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.04] ${
              wide ? 'aspect-[16/10] md:aspect-[21/9]' : 'aspect-[16/10]'
            }`}
            loading="lazy"
          />
          <span className="absolute top-4 left-4 border border-line bg-ink/70 px-3 py-1.5 font-mono text-[10px] tracking-[0.18em] text-dim uppercase backdrop-blur">
            {project.year}
          </span>
          <span className="absolute top-4 right-4 border border-accent/60 bg-ink/70 px-3 py-1.5 font-mono text-[10px] tracking-[0.18em] text-accent uppercase backdrop-blur">
            {project.status}
          </span>
        </div>

        <div className="flex grow flex-col p-7 md:p-9">
          <p className="font-mono text-[10px] tracking-[0.22em] text-dim uppercase">
            {project.category}
          </p>
          <h3 className="mt-4 text-xl leading-snug font-bold tracking-tight md:text-2xl">
            {project.title}
          </h3>
          <p className="mt-5 max-w-[62ch] text-[14px] leading-relaxed text-dim md:text-[15px]">
            {project.summary}
          </p>

          <p className="mt-7 border-t border-line pt-5 text-[13px] leading-relaxed text-fog/85">
            <span className="font-mono text-[10px] tracking-[0.2em] text-accent uppercase">
              Role
            </span>
            <span className="mt-2 block">{project.role}</span>
          </p>

          <ul className="mt-6 flex flex-wrap gap-x-5 gap-y-2">
            {project.deliverables.map((item) => (
              <li key={item} className="font-mono text-[11px] text-dim">
                <span className="text-accent">／</span> {item}
              </li>
            ))}
          </ul>
        </div>
      </article>
    </Reveal>
  )
}

export default function Work() {
  return (
    <section id="work" className="pb-24 md:pb-36">
      <SectionHeading
        index="02 / Selected Work"
        title="精选项目"
        lead="三个我能完整讲清的项目：一个竞赛作品、一个独立开发的小程序原型、一篇正在做的产品作品。每一个都附上了我的角色和交付物。"
      />

      <div className="shell mt-14 grid grid-cols-12 gap-4 md:gap-8">
        {profile.projects.map((project) => (
          <ProjectCard key={project.title} project={project} wide={Boolean(project.wide)} />
        ))}
      </div>
    </section>
  )
}