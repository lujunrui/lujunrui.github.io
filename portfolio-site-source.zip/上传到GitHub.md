# 上传到 GitHub —— 操作步骤

> 这份文件是给你自己看的。上传完之后，如果忘了怎么做，随时回来翻。

## 一、准备

1. 把我给你的 `portfolio-site-source.zip` 解压到任意位置（例如桌面新建一个文件夹）。
2. **不要上传 `node_modules` 文件夹**：那是我安装依赖时生成的，体积几百 MB、文件上万个。
   打包时我已经把它排除了，所以你只要拖我给的这些文件就对了。
3. GitHub 网页上传一次最多 100 个文件，本项目的文件数量远低于这个限制。

## 二、方法 A：网页上传（最简单，不用装任何软件）

1. 打开 <https://github.com>，登录 → 右上角 `+` → **New repository**。
2. **Repository name** 填 `portfolio-site`；**Public**（任何人可见）或 **Private** 都可以，
   不影响后面部署；不要勾选 "Add a README file"（避免多出无关文件）。
3. 点 **Create repository**。
4. 在新仓库页面点 **uploading an existing file**。
5. 把解压出来的**所有文件和文件夹全部拖进**页面，包括：
   - 文件夹：`src`、`public`
   - 文件：`index.html`、`package.json`、`package-lock.json`、`vite.config.js`、
     `README.md`、`启动预览.bat`、`上传到GitHub.md`
   - `.gitignore` 是隐藏文件，能传就传（传不上不影响部署）
6. 页面下方点 **Commit changes**。
7. 回到仓库首页检查：能不能看到 `src` 和 `public` 两个文件夹。能看到就成功了。

## 三、方法 B：GitHub Desktop（推荐，以后改内容更省事）

1. 下载安装 **GitHub Desktop**，用你的 GitHub 账号登录。
2. 菜单 **File → Add local repository**，选择解压出来的文件夹。
3. 如果提示 *not a git repository*，点 **create a repository** 即可。
4. 点 **Publish repository**（想公开就取消勾选 "Keep this code private"）。

## 四、下一步：让它变成「有网址、任何人能看」

代码在 GitHub 上还不等于有网址。有两种方式：

### 方式一（推荐，免费、最快）：Netlify

1. 打开 <https://www.netlify.com>，用 GitHub 账号直接登录（不用另外注册）。
2. **Add new site → Import an existing project → GitHub**，授权并选中 `portfolio-site` 仓库。
3. 构建配置填：
   - Build command：`npm run build`
   - Publish directory：`dist`
4. 点 **Deploy**。等一两分钟，你会拿到类似 `https://xxxxxx.netlify.app` 的网址——
   **这个网址任何人都能打开，手机上也能打开。**

### 方式二：GitHub Pages

本项目是 React + Vite，需要先构建才能部署，GitHub Pages 配置比 Netlify 麻烦一些。
如果你要走这条路，告诉我，我把 `.github/workflows` 的自动构建配置写好给你。

### 想要自己的域名（例如 `你的名字.com`）

1. 在域名商（阿里云 / 腾讯云 / Namecheap 等）购买域名，约 ¥30–70/年，需要实名。
2. 在 Netlify 的 **Domain management** 里添加这个域名，按提示到域名商后台改 DNS 记录。
3. 提醒：`netlify.app` 这类免费国际托管在**国内访问不稳定**。如果主要是给国内 HR 看，
   更稳的是国内对象存储（阿里云 OSS / 腾讯云 COS）+ 自有域名 + ICP 备案（约 1–3 周）。

### 想登录网页后台自己改资料

站点内容目前集中在一个文件里；我可以把它配成 **Decap CMS** 网页后台：
登录 `/admin` 就能像填表一样改文字、换照片，保存后网站自动更新，手机浏览器也能用。
需要的时候跟我说，我来配。

## 五、以后在本地继续改动

1. 电脑需要装 **Node.js**（<https://nodejs.org>，选 LTS 版本）。
2. 在项目文件夹里双击 **`启动预览.bat`**，等它自动打开浏览器即可预览。
3. **改文字、改占位符，只需要改一个文件：`src/data/profile.js`**
   （姓名、邮箱、手机、微信号、自我介绍、项目描述都在里面）。
4. 改完保存，浏览器会自动刷新。觉得满意再上传到 GitHub（重复方法 A 的第 4–6 步，
   或直接用 GitHub Desktop 提交推送）。

## 六、目录说明

```
portfolio-site/
├─ index.html            HTML 入口（网页标题、描述在这里）
├─ package.json          依赖与命令（npm run dev / build）
├─ package-lock.json     依赖版本锁定
├─ vite.config.js        构建与端口配置（预览端口 5183）
├─ src/
│  ├─ index.css          颜色、字体、版心宽度等设计变量
│  ├─ main.jsx           程序入口
│  ├─ App.jsx            页面组装（含无障碍跳转链接）
│  ├─ data/profile.js    ★ 全站文字内容都在这里，改文案只改这一个文件
│  ├─ components/        导航、首屏动效、入场动画、小标题
│  └─ sections/          5 个区块：首屏 / 经历 / 项目 / 优势 / 联系
├─ public/
│  ├─ assets/images/     图片（人像、3 张项目配图，目前是占位 SVG）
│  ├─ assets/videos/     视频背景说明（启用方法见该目录 README）
│  └─ fonts/             本地字体（Outfit、Geist Mono）
├─ 启动预览.bat          双击即可本地预览
└─ README.md             项目总说明
```