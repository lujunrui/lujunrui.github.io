@echo off
chcp 65001 >nul
title Portfolio Site - Local Preview
cd /d "%~dp0"
set "PATH=D:\果办\OfficeAce\tools\node;%PATH%"

echo ============================================
echo    作品集网站 - 本地预览
echo ============================================
echo.
echo   预览地址: http://127.0.0.1:5183/
echo   浏览器会自动打开
echo.
echo   关闭这个黑色窗口 = 停止预览
echo.

start "" cmd /c "ping -n 5 127.0.0.1 >nul & start http://127.0.0.1:5183/"

call npm run dev

echo.
echo 预览已停止。
pause >nul